package edu.rit.sketchpad.sketchpad;

import android.graphics.Canvas;
import android.graphics.*;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import java.io.*;

public class MainActivity extends AppCompatActivity
{
    Bitmap bitmap;
    Canvas canvas;
    PaintView myPaintView;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myPaintView = new PaintView(this,null);
        bitmap = Bitmap.createBitmap(320,480,Bitmap.Config.ARGB_8888);
        canvas = new Canvas(bitmap);

    }


    public void buttonOnClick(View v)
    {
        File folder = new File(Environment.getExternalStorageDirectory().toString());
        boolean saved = false;
        if(!folder.exists())
        {
            saved = folder.mkdirs();
        }
        Toast.makeText(MainActivity.this,saved+"folder", Toast.LENGTH_SHORT);
        File file = new File(Environment.getExternalStorageDirectory().toString()+ "/test.png");
        if(!file.exists())
        {
            try {
                saved = file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        Toast.makeText(MainActivity.this,saved+"file", Toast.LENGTH_SHORT);
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        bitmap = myPaintView.getBitmap();
        Bitmap saveMap = Bitmap.createBitmap(320, 480, Bitmap.Config.ARGB_8888);
        Paint paint = new Paint();
        paint.setColor(Color.WHITE);
        Canvas now = new Canvas(saveMap);
        now.drawBitmap(bitmap, new Rect(0,0,bitmap.getWidth(),bitmap.getHeight()), new Rect(0,0,320,480), null);
        if(saveMap==null)
        {
            System.out.println("NULL bitmap save\n");
        }
        saveMap.compress(Bitmap.CompressFormat.PNG,100,out);

        /*
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "TEST");
        values.put(MediaStore.Images.Media.DESCRIPTION, "DESCRIPTION");
        values.put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis());
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        values.put(MediaStore.MediaColumns.DATA, new Path().toString());

        getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        */
        /*
        ContentResolver cr = getContentResolver();
        String title = "Test";
        String description = "A test file";
        MediaStore.Images.Media.insertImage(cr,bitmap,title,description);
        String savedURL = MediaStore.Images.Media.insertImage(cr,bitmap,title,description);

        Toast.makeText(MainActivity.this,savedURL,Toast.LENGTH_LONG).show();
        */
        /*
        String root = Environment.getExternalStorageDirectory().toString();
        File myDir = new File(root + "/saved_images");
        myDir.mkdirs();
        Random generator = new Random();
        int n = 10000;
        n = generator.nextInt(n);
        String fname = "Image-"+ n +".jpg";
        File file = new File (myDir, fname);
        if (file.exists ()) file.delete ();
        try {
            FileOutputStream out = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
            out.flush();
            out.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        sendBroadcast(new Intent(
                Intent.ACTION_MEDIA_MOUNTED,
                Uri.parse("file://" + Environment.getExternalStorageDirectory())));
        */
    }



    public void onDraw(Canvas c)
    {
        //Drawing stuff goes in here
    }
}
