package edu.rit.sketchpad.sketchpad;

import android.content.*;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.*;

/**
 * Created by peterwengert on 10/3/17.
 */

public class PaintView extends View {
    private Bitmap myBitmap;
    private Canvas myCanvas;
    private Path myPath;
    private Paint myBitmapPaint;
    private Paint myPaint;

    public PaintView(Context con, AttributeSet attrib)
    {
        super(con, attrib);

        //Set attributes to default values
        myPath = new Path();
        myBitmapPaint = new Paint(Paint.DITHER_FLAG);
        myPaint = new Paint();
        myPaint.setAntiAlias(true);
        myPaint.setDither(true);
        myPaint.setColor(0xFF000000);
        myPaint.setStyle(Paint.Style.STROKE);
        myPaint.setStrokeJoin(Paint.Join.ROUND);
        myPaint.setStrokeCap(Paint.Cap.ROUND);
        myPaint.setStrokeWidth(9);
    }

    public Bitmap getBitmap()
    {
        return myBitmap;
    }

    public void onDraw(Canvas canvas)
    {
        int x = 5; //Replace with code later
    }

    //Make all drawing and painting methods in this class!
}